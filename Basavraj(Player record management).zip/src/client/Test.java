package client;

import java.util.Scanner;
import service.World;
import serviceimpl.India;

public class Test
{
	public static void main(String[] args) 
	{
		World w = new India();
		Scanner sc = new Scanner(System.in);
		while(true)
		{
		System.out.println("----Welcome to Team INDIA----");
		System.out.println(" Press 1 for player addition\n Press 2 for view Player information\n Press 3 for view Player Indivisual Score\n Press 4 for Update Score for indivisual Player\n Press 5 for Exit");
		int a = sc.nextInt();
		
		switch(a)
		{
		case 1:
			w.addPlayer();
			break;
		
		case 2:
			w.viewPlayer();
			break;
			
		case 3:
			w.viewScore();
			 break;
			 
		case 4:
			w.updateScore();
			break;
			
		case 5:
			System.out.println("Thank you! VIsit Again");
			System.exit(0);
		
		}
		
		
	}
  }
}
