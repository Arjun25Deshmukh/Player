package service;

public interface World 
{
	public void addPlayer();
	public void viewPlayer();
	public void viewScore();
	public void updateScore();

}
