
package serviceimpl;
import java.util.Scanner;
import model.Player;
import service.World;
public class India implements World
{
	
	Scanner sc = new Scanner(System.in);
	Player p1 = new Player();
	Player p2 = new Player();
	Player p3 = new Player();
	Player p4 = new Player();
	Player p5 = new Player();

	public void addPlayer() 
	{
	 System.out.println(" Enter a case number for which player is to be add");
	 System.out.println(" Press 1 for First player.\n Press 2 for Second player.\n Press 3 for third player.\n Press 4 for fourth player.\n Press 5 for fifth player.");
	 int a = sc.nextInt();
	 
	 switch(a)
	 {
	 case 1:
		  System.out.println("----Please fill Information of 1st Player----");
          System.out.println("Enter a Rank of the Player");
          int b = sc.nextInt();
          p1.setRankno(b);
          System.out.println("Enter a name of player");
          String c = sc.next()+sc.nextLine();
          p1.setPname(c);
          System.out.println("Enter a age of player");
          int d = sc.nextInt();
          p1.setAge(d);
          System.out.println("Enter a previous score of player");
          int e = sc.nextInt();
          p1.setPscore(e);
          System.out.println("Enter a status of player i.e.true or false format");
          boolean f = sc.nextBoolean();
          p1.setPstatus(f);
          break;
	 case 2:
		 System.out.println("----Please fill Information of 2nd Player----");
		 System.out.println("Enter a Rank of the Player");
         int b1 = sc.nextInt();
         p2.setRankno(b1);
         System.out.println("Enter a name of player");
         String c1 = sc.next()+sc.nextLine();
         p2.setPname(c1);
         System.out.println("Enter a age of player");
         int d1 = sc.nextInt();
         p2.setAge(d1);
         System.out.println("Enter a previous score of player");
         int e1 = sc.nextInt();
         p2.setPscore(e1);
         System.out.println("Enter a status of player i.e.true or false format");
         boolean f1 = sc.nextBoolean();
         p2.setPstatus(f1);
         break;
	 
	 case 3:
		 System.out.println("----Please fill Information of 3rd Player----");
		 System.out.println("Enter a Rank of the Player");
         int b2 = sc.nextInt();
         p3.setRankno(b2);
         System.out.println("Enter a name of player");
         String c2 = sc.next()+sc.nextLine();
         p3.setPname(c2);
         System.out.println("Enter a age of player");
         int d2 = sc.nextInt();
         p3.setAge(d2);
         System.out.println("Enter a previous score of player");
         int e2 = sc.nextInt();
         p3.setPscore(e2);
         System.out.println("Enter a status of player i.e.true or false format");
         boolean f2 = sc.nextBoolean();
         p3.setPstatus(f2);
         break; 
	 
	 case 4:
		 System.out.println("----Please fill Information of 4th Player----");
		 System.out.println("Enter a Rank of the Player");
         int b3 = sc.nextInt();
         p4.setRankno(b3);
         System.out.println("Enter a name of player");
         String c3 = sc.next()+sc.nextLine();
         p4.setPname(c3);
         System.out.println("Enter a age of player");
         int d3 = sc.nextInt();
         p4.setAge(d3);
         System.out.println("Enter a previous score of player");
         int e3 = sc.nextInt();
         p4.setPscore(e3);
         System.out.println("Enter a status of player i.e.true or false format");
         boolean f3 = sc.nextBoolean();
         p4.setPstatus(f3);
         break;
         
	 case 5:
		 System.out.println("----Please fill Information of 5th Player----");
		 System.out.println("Enter a Rank of the Player");
         int b4 = sc.nextInt();
         p5.setRankno(b4);
         System.out.println("Enter a name of player");
         String c4 = sc.next()+sc.nextLine();
         p5.setPname(c4);
         System.out.println("Enter a age of player");
         int d4 = sc.nextInt();
         p5.setAge(d4);
         System.out.println("Enter a previous score of player");
         int e4 = sc.nextInt();
         p5.setPscore(e4);
         System.out.println("Enter a status of player i.e.true or false format");
         boolean f4 = sc.nextBoolean();
         p5.setPstatus(f4);
         break;
         
	 }
	 
	}
	public void viewPlayer()
	{
		System.out.println(" Enter a case number for which player to view their Information ");
		System.out.println(" Press 1 for First player.\n Press 2 for Second player.\n Press 3 for third player.\n Press 4 for fourth player.\n Press 5 for fifth player.");
		int a = sc.nextInt();
		 
		 switch(a)
		 {
		 case 1:
			  System.out.println("----1st Player Information----");
	          System.out.println("Player Rank is =" +p1.getRankno());
	          System.out.println("Player Name is =" +p1.getPname());
	          System.out.println("Player Age is =" +p1.getAge());
	          System.out.println("Player Score is =" +p1.getPscore());
	          System.out.println("Player Status is =" +p1.getPstatus());
	          break;
		 case 2:
			  System.out.println("----2nd Player Information----");
			  System.out.println("Player Rank is =" +p2.getRankno());
	          System.out.println("Player Name is =" +p2.getPname());
	          System.out.println("Player Age is =" +p2.getAge());
	          System.out.println("Player Score is =" +p2.getPscore());
	          System.out.println("Player Status is =" +p2.getPstatus());
	          break;
		 
		 case 3:
			 System.out.println("----3rd Player Information----");
			  System.out.println("Player Rank is =" +p3.getRankno());
	          System.out.println("Player Name is =" +p3.getPname());
	          System.out.println("Player Age is =" +p3.getAge());
	          System.out.println("Player Score is =" +p3.getPscore());
	          System.out.println("Player Status is =" +p3.getPstatus());
	          break;

		 
		 case 4:
			 System.out.println("----4th Player Information----");
			  System.out.println("Player Rank is =" +p4.getRankno());
	          System.out.println("Player Name is =" +p4.getPname());
	          System.out.println("Player Age is =" +p4.getAge());
	          System.out.println("Player Score is =" +p4.getPscore());
	          System.out.println("Player Status is =" +p4.getPstatus());
	          break;

		 case 5:
			 System.out.println("----5th Player Information----");
			  System.out.println("Player Rank is =" +p5.getRankno());
	          System.out.println("Player Name is =" +p5.getPname());
	          System.out.println("Player Age is =" +p5.getAge());
	          System.out.println("Player Score is =" +p5.getPscore());
	          System.out.println("Player Status is =" +p5.getPstatus());
	          break;
		 }
	   		
	}
	public void viewScore()
	{
		System.out.println(" Enter a case number for which player to view the Current Score");
		System.out.println(" Press 1 for First player.\n Press 2 for Second player.\n Press 3 for third player.\n Press 4 for fourth player.\n Press 5 for fifth player.");
		int a = sc.nextInt();
		 
		 switch(a)
		 {
		 case 1:
	          System.out.println(" Current Score for the First player is =" +p1.getPscore());
	          break;
		 case 2:
			 System.out.println(" Current Score for the Second player is =" +p2.getPscore());
	         break;
		 
		 case 3:
			 System.out.println(" Current Score for the Third player is =" +p3.getPscore());
	         break;
		 
		 case 4:
			 System.out.println(" Current Score for the Fourth player is =" +p4.getPscore());
	         break;
		 case 5:
			 System.out.println(" Current Score for the Fifth player is =" +p5.getPscore());
	         break;
		 }
		
	}
	public void updateScore()
	{
		System.out.println(" Enter a case number for which player to Update Score");
		System.out.println(" Press 1 for First player.\n Press 2 for Second player.\n Press 3 for third player.\n Press 4 for fourth player.\n Press 5 for fifth player.");
		int a = sc.nextInt();
		 switch(a)
		 {
		 case 1:
	          System.out.println("Enter Updated Score");
	          int newScore = sc.nextInt();
	          int oldScore =p1.getPscore();
	          int updatedScore = newScore+oldScore;
	          p1.setPscore(updatedScore);
	          System.out.println("Updated Score for First player is =" +p1.getPscore());
	          break;
		 case 2:
			  System.out.println("Enter Updated Score");
			  int newscore = sc.nextInt();
	          int oldscore =p2.getPscore();
	          int updatedscore = newscore+oldscore;
	          p2.setPscore(updatedscore);
	          System.out.println("Updated Score for Second player is =" +p2.getPscore());
	          break;
		 
		 case 3:
			  System.out.println("Enter Updated Score");
			  int Newscore = sc.nextInt();
	          int Oldscore =p3.getPscore();
	          int Updatedscore = Newscore+Oldscore;
	          p3.setPscore(Updatedscore);
	          System.out.println("Updated Score for Third player is =" +p3.getPscore());
	          break;
		 
		 case 4:
			  System.out.println("Enter Updated Score");
			  int NewScore = sc.nextInt();
	          int OldScore =p4.getPscore();
	          int UpdatedScore = NewScore+OldScore;
	          p4.setPscore(UpdatedScore);
	          System.out.println("Updated Score for Fourth player is =" +p4.getPscore());
	          break;
		 case 5:
			  System.out.println("Enter Updated Score");
			  int neWscore = sc.nextInt();
	          int olDscore =p5.getPscore();
	          int UpdatedSCORE = neWscore+olDscore;
	          p5.setPscore(UpdatedSCORE);
	          System.out.println("Updated Score for Fifth player is =" +p5.getPscore());
	          break;
		 }	
	}
    
    }
